<!--
SEO / AEO METADATA
Target query:      what happened to NIOSH 2026 industrial hygiene
Meta title:        NIOSH Nearly Vanished in 2025 — What Its 2026 Return Means
Meta description:  NIOSH lost roughly 90% of its staff to 2025 layoffs, then was fully reinstated in January 2026. Here's what the whiplash means for industrial hygiene practice.
Slug:              /niosh-2026-reinstatement-what-it-means-for-ih
Primary entity:    NIOSH (National Institute for Occupational Safety and Health)
-->

# NIOSH Almost Disappeared — What Its 2026 Reinstatement Means for Industrial Hygiene

**Short answer:** In April 2025, HHS issued layoff notices to roughly 90% of NIOSH's staff. After nine months of legal challenges and public pressure, HHS revoked all the notices on January 13, 2026, reinstating the workforce. For industrial hygienists, the agency is back — but the episode was a sharp reminder of how much of daily IH practice quietly depends on it.

## What actually happened to NIOSH?

A near-total staffing cut, then a full reversal, over about nine months:

- **April 2025:** HHS sent reduction-in-force notices to roughly 900–1,000 NIOSH employees — about 90% of the agency.[1][4]
- **Through 2025:** some staff were brought back amid lawsuits and congressional pressure, but hundreds sat on paid administrative leave for months.[1][3]
- **January 13, 2026:** HHS reversed course entirely and revoked all remaining layoff notices.[1][2][4]
- **Funding:** the House passed appropriations including about $366.8 million for NIOSH — an increase over the prior year.[5]

## Why does NIOSH matter to working industrial hygienists?

Because you likely touch its work every week without thinking about it. NIOSH:

- **Approves respirators** — the N95s and other equipment your programs depend on
- **Publishes sampling and analytical methods** (the NIOSH Manual of Analytical Methods) that labs run every day
- **Sets Recommended Exposure Limits (RELs)** and health-based guidance
- **Runs research, Health Hazard Evaluations, and programs** for miners and first responders

When the agency stalled, respirator approvals backed up, PPE-related work paused, and even counterfeit-respirator detection slowed. That's not abstract — it's the plumbing of the profession.

## Is NIOSH fully back to normal in 2026?

Not quite. The people are reinstated, but the disruption left marks:

- Some experienced staff took other jobs during the nine-month limbo and didn't return
- Backlogs built up — respirator applications, research projects, program work[5]
- Rebuilding institutional momentum takes time[5]

Expect a functioning agency that's still working through a backlog for a while.

## What should consultancies take from this?

Two practical lessons worth internalizing:

- **Don't treat federal timelines as guaranteed.** Build slack into any project that depends on NIOSH approvals, methods, or guidance.
- **The data you control is the data you can count on.** When public infrastructure wobbles, the value of your own complete, retrievable records goes up.

The bigger headline, though, is simply this: NIOSH is back, and the profession is better for it.

## Frequently asked questions

**Was NIOSH shut down?**
No. Layoffs targeted about 90% of staff in 2025, but the agency was never formally dissolved, and all layoff notices were revoked in January 2026.

**Does NIOSH set legal exposure limits?**
No. NIOSH publishes Recommended Exposure Limits (RELs) as guidance; OSHA sets the legally enforceable PELs.

**Are NIOSH respirator approvals still valid?**
Yes. Existing approvals remain valid, and the approval program is operating again after the 2025 delays.

---

*This post is part of our ongoing coverage of national industrial hygiene developments. [See more from myIH.](https://myihportal.com)*

## References

1. Heckman, Jory. "HHS Reinstates All Laid-Off Employees at Workplace Safety Agency NIOSH." Federal News Network, 14 Jan. 2026, https://federalnewsnetwork.com/workforce/2026/01/hhs-reinstates-all-laid-off-employees-at-workplace-safety-agency-niosh/.
2. "HHS Reverses Layoffs at CDC's Work Safety Research Division." Healthcare Dive, 14 Jan. 2026, https://www.healthcaredive.com/news/hhs-rescinds-niosh-layoffs-cdc/809584/.
3. "NIOSH Employees Reinstated in Victory for Workers and Public." American Federation of Government Employees, https://www.afge.org/article/niosh-employees-reinstated-in-victory-for-workers-and-public/.
4. "Federal Government Revokes Layoff Notices for NIOSH Staff." Safety+Health, National Safety Council, 16 Jan. 2026, https://www.safetyandhealthmagazine.com/articles/27736-federal-government-revokes-layoff-notices-for-niosh-staff.
5. "Victory! NIOSH Staff Reinstated!" Occupational, Environmental, and Climate Medicine, UCSF, https://oecm.ucsf.edu/news/victory-niosh-staff-reinstated.

<!--
PASTE-READY FAQ SCHEMA (JSON-LD)
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {"@type": "Question", "name": "Was NIOSH shut down?", "acceptedAnswer": {"@type": "Answer", "text": "No. Layoffs targeted about 90% of staff in 2025, but the agency was never formally dissolved, and all layoff notices were revoked in January 2026."}},
    {"@type": "Question", "name": "Does NIOSH set legal exposure limits?", "acceptedAnswer": {"@type": "Answer", "text": "No. NIOSH publishes Recommended Exposure Limits as guidance; OSHA sets the legally enforceable Permissible Exposure Limits."}},
    {"@type": "Question", "name": "Are NIOSH respirator approvals still valid?", "acceptedAnswer": {"@type": "Answer", "text": "Yes. Existing approvals remain valid, and the approval program is operating again after the 2025 delays."}}
  ]
}
</script>
-->
