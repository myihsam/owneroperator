<!--
SEO / AEO METADATA
Target query:      ACGIH 2026 TLV changes NIC industrial hygiene
Meta title:        ACGIH's 2026 TLV Changes: What IH Pros Should Be Watching
Meta description:  ACGIH's 2026 Notice of Intended Changes flags new and lower exposure limits. Here's what's on the list — and why TLVs still outpace OSHA's PELs.
Slug:              /acgih-2026-tlv-changes-nic
Primary entity:    ACGIH Threshold Limit Values (TLVs)
-->

# ACGIH's 2026 TLV Changes: What Industrial Hygienists Should Be Watching

**Short answer:** ACGIH's 2026 Notice of Intended Changes (NIC) proposes new or revised Threshold Limit Values for several chemicals — an early signal of where exposure expectations are heading. TLVs aren't legally enforceable, but they often move faster and lower than OSHA's decades-old PELs. That gap is exactly why hygienists watch the NIC list closely.

## What is the ACGIH NIC, and why does it matter?

The NIC is ACGIH's "coming attractions" list. Each year the organization reviews the science and publishes proposed changes before formally adopting them, giving hygienists a heads-up.

- A chemical on the NIC may receive a new or lower TLV in a future edition.
- A lower proposed value usually means new evidence suggests harm at levels once considered safe.
- It's your early warning to reassess sampling strategy and controls *before* a limit tightens.

## What's on the 2026 list?

Proposed changes (NIC) for chemical substances include:

- Aniline
- n-Butyl propionate
- Carbon monoxide (comment period closed)
- Citronellol
- Geraniol and related compounds
- Propargyl alcohol

There's also a Biological Exposure Indices (BEI) NIC for **methyl ethyl ketone**.[1][3]

Separately, ACGIH keeps an **"Under Study" list** — a watchlist for potential future action — which in 2026 includes benzene, lead, glyphosate, 1,3-butadiene, aluminum, bisphenol A, antimony, phenol, and others.[1]

## Are TLVs the same as legal limits?

No — and this distinction trips people up constantly.

- **TLVs** are health-based *guidelines* from ACGIH, meant to be interpreted and applied by trained industrial hygienists.[5]
- **OSHA PELs** are the legally *enforceable* limits.[5]
- Many PELs date back to the 1970s and haven't kept pace with the science.

The gap can be dramatic. When ACGIH lowered its benzene TLV to 0.02 ppm, that was **25 times lower** than its own prior value — and roughly **50 times lower** than OSHA's still-current 1 ppm PEL.[2] A workplace can be fully OSHA-compliant and still sit well above the level ACGIH considers protective.[2]

## What should you do with the NIC?

- **Flag any NIC chemical your clients handle** and re-check recent sampling against the proposed value.
- **Where a TLV is trending down, model it forward** — would current controls still pass at the lower number?
- **Document the reasoning.** Showing you assessed against the best available science is good practice and strengthens defensibility.

The point of the NIC isn't panic — it's lead time. Firms that track it get to advise clients before a change lands, not scramble after.

## Frequently asked questions

**What does NIC stand for?**
Notice of Intended Changes — ACGIH's list of proposed TLV and BEI revisions published before formal adoption.

**Are TLVs legally enforceable?**
No. They're health-based guidelines. OSHA PELs are the enforceable limits.

**Why are ACGIH TLVs often lower than OSHA PELs?**
Because ACGIH updates TLVs regularly based on new science, while many OSHA PELs haven't changed in decades.

---

*Tracking exposure-limit changes for your clients? [See how myIH keeps IH field data organized.](https://myihportal.com)*

## References

1. "Substances and Agents Listing." ACGIH, https://www.acgih.org/science/tlv-bei-guidelines/documentation-publications-and-data/substances-and-agents-listing/.
2. "The American Conference of Governmental Industrial Hygienists Reduces Its Threshold Limit Value for Benzene." Gradient, 29 Dec. 2025, https://gradientcorp.com/trend_articles/acgih-reduces-tlv-for-benzene/.
3. "Spring 2026 Notice of Intended Changes List (NICs)." ACGIH, https://www.acgih.org/science/tlv-bei-guidelines/documentation-publications-and-data/notice-of-intended-changes/notice-of-intended-changes-list/.
4. "Notice of Intended Changes." ACGIH, https://www.acgih.org/science/tlv-bei-guidelines/documentation-publications-and-data/notice-of-intended-changes/.
5. "Permissible Exposure Limits – Important Note Regarding the ACGIH TLV." Occupational Safety and Health Administration, https://www.osha.gov/annotated-pels/note.

<!--
PASTE-READY FAQ SCHEMA (JSON-LD)
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {"@type": "Question", "name": "What does NIC stand for in industrial hygiene?", "acceptedAnswer": {"@type": "Answer", "text": "Notice of Intended Changes — ACGIH's list of proposed TLV and BEI revisions published before formal adoption."}},
    {"@type": "Question", "name": "Are ACGIH TLVs legally enforceable?", "acceptedAnswer": {"@type": "Answer", "text": "No. They are health-based guidelines. OSHA Permissible Exposure Limits are the enforceable limits."}},
    {"@type": "Question", "name": "Why are ACGIH TLVs often lower than OSHA PELs?", "acceptedAnswer": {"@type": "Answer", "text": "Because ACGIH updates TLVs regularly based on new science, while many OSHA PELs have not changed in decades."}}
  ]
}
</script>
-->
